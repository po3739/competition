﻿#ifndef __TIMER_H
#define __TIMER_H

extern volatile uint16_t Light_Value;
extern volatile uint8_t Flag_100ms;
void Timer_Init(void);

#endif
