﻿#include "stm32f10x.h"
#include "PWM.h"
#include "Motor.h"

/* STBY按当前实际接线固定接3.3V；只使用A通道固定转向。 */
void Motor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	PWM_Init();
}

/* 参数为0~999的PWM比较值，不能用int8_t接收12位ADC。 */
void Motor_setspeed(uint16_t Speed)
{
	if (Speed > 999)
	{
		Speed = 999;
	}
	if (Speed == 0)
	{
		PWM_SetCompare1(0);
		GPIO_ResetBits(GPIOB, GPIO_Pin_12 | GPIO_Pin_13);
	}
	else
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_12);
		GPIO_ResetBits(GPIOB, GPIO_Pin_13);
		PWM_SetCompare1(Speed);
	}
}
