﻿#ifndef __ALARM_H
#define __ALARM_H
#include<stdint.h>

void Alarm_Init(void);
void BEEP_Set(uint8_t sta);
void LED_Alarm_Set(uint8_t sta);

#endif
