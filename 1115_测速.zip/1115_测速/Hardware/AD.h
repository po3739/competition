#ifndef _AD_H
#define _AD_H
#include<stdint.h>

void AD_Init(void);
uint16_t AD_GetValue(void);


#endif
