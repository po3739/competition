﻿#include "stm32f10x.h"
#include "Delay.h"
#include "Key.h"

extern uint8_t Motor_Enable;
extern uint16_t Light_Thresh;

void Key_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

/* 沿用本工程直接修改启停/阈值的方式，不在函数内一直等待松手。 */
void Key_GetNum(void)
{
	static uint8_t Key1Flag = 0;
	static uint8_t Key2Flag = 0;
	static uint8_t Key3Flag = 0;

    if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0)
    {
        if (Key1Flag == 0)
        {
            Delay_ms(20);
            if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 0)
            {
                Key1Flag = 1;
                if (Motor_Enable == 1)
                {
                    Motor_Enable = 0;
                }
                else
                {
                    Motor_Enable = 1;
                }
            }
        }
    }
    else
    {
        if (Key1Flag == 1)
        {
            Delay_ms(20);
            if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1) == 1)
            {
                Key1Flag = 0;
            }
        }
    }

    if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 0)
    {
        if (Key2Flag == 0)
        {
            Delay_ms(20);
            if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 0)
            {
                Key2Flag = 1;
                if (Light_Thresh <= 3995)
                {
                    Light_Thresh = Light_Thresh + 100;
                }
                else
                {
                    Light_Thresh = 4095;
                }
            }
        }
    }
    else
    {
        if (Key2Flag == 1)
        {
            Delay_ms(20);
            if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_2) == 1)
            {
                Key2Flag = 0;
            }
        }
    }

    if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == 0)
    {
        if (Key3Flag == 0)
        {
            Delay_ms(20);
            if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == 0)
            {
                Key3Flag = 1;
                if (Light_Thresh >= 100)
                {
                    Light_Thresh = Light_Thresh - 100;
                }
                else
                {
                    Light_Thresh = 0;
                }
            }
        }
    }
    else
    {
        if (Key3Flag == 1)
        {
            Delay_ms(20);
            if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_3) == 1)
            {
                Key3Flag = 0;
            }
        }
    }
}
