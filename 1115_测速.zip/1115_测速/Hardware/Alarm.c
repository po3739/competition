﻿#include "stm32f10x.h"                  // Device header
#include "alarm.h"

void Alarm_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_SetBits(GPIOB, GPIO_Pin_0 | GPIO_Pin_1);
}

void BEEP_Set(uint8_t sta)
{
    if(sta==1)
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_0);
	}
    else 
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_0);
	}
}

void LED_Alarm_Set(uint8_t sta)
{
    if(sta==1) 
	{
		GPIO_ResetBits(GPIOB, GPIO_Pin_1);
	}
    else    
	{
		GPIO_SetBits(GPIOB, GPIO_Pin_1);
	}
}
