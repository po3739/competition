#include "stm32f10x.h"
#include "OLED.h"

#define SAMPLE_MS 100U
/* Set each value to the absolute count change for one full wheel turn. */
#define A_COUNTS_PER_REV 0U
#define B_COUNTS_PER_REV 0U

/* These globals are still referenced by the existing Key module. */
uint16_t Light_Thresh = 2000;
uint8_t Motor_Enable = 0;

static void Motor_Disable(void)
{
	GPIO_InitTypeDef gpio;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_ResetBits(GPIOA, GPIO_Pin_8);
	GPIO_ResetBits(GPIOB, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_12 |
		GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15);

	gpio.GPIO_Mode = GPIO_Mode_Out_PP;
	gpio.GPIO_Speed = GPIO_Speed_2MHz;
	gpio.GPIO_Pin = GPIO_Pin_8;
	GPIO_Init(GPIOA, &gpio);
	gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_12 |
		GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_Init(GPIOB, &gpio);
}

static void Encoder_Init(void)
{
	GPIO_InitTypeDef gpio;
	TIM_ICInitTypeDef input;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM4, ENABLE);
	gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	gpio.GPIO_Speed = GPIO_Speed_2MHz;
	gpio.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_Init(GPIOA, &gpio);
	gpio.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_Init(GPIOB, &gpio);

	TIM_ICStructInit(&input);
	input.TIM_ICFilter = 6;
	input.TIM_Channel = TIM_Channel_1;
	TIM_ICInit(TIM2, &input);
	TIM_ICInit(TIM4, &input);
	input.TIM_Channel = TIM_Channel_2;
	TIM_ICInit(TIM2, &input);
	TIM_ICInit(TIM4, &input);
	TIM_EncoderInterfaceConfig(TIM2, TIM_EncoderMode_TI12,
		TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12,
		TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_SetAutoreload(TIM2, 65535);
	TIM_SetAutoreload(TIM4, 65535);
	TIM_SetCounter(TIM2, 0);
	TIM_SetCounter(TIM4, 0);
	TIM_Cmd(TIM2, ENABLE);
	TIM_Cmd(TIM4, ENABLE);
}

static void SampleTimer_Init(void)
{
	RCC_ClocksTypeDef clocks;
	TIM_TimeBaseInitTypeDef timer;
	uint32_t timerClock;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	RCC_GetClocksFreq(&clocks);
	timerClock = clocks.PCLK2_Frequency;
	if (clocks.PCLK2_Frequency != clocks.HCLK_Frequency)
	{
		timerClock *= 2U;
	}
	TIM_TimeBaseStructInit(&timer);
	timer.TIM_Prescaler = (uint16_t)(timerClock / 10000U - 1U);
	timer.TIM_Period = 65535;
	TIM_TimeBaseInit(TIM1, &timer);
	TIM_Cmd(TIM1, ENABLE);
}

static int32_t Encoder_Delta(uint16_t now, uint16_t previous)
{
	uint16_t difference = (uint16_t)(now - previous);

	if (difference > 32767U)
	{
		return (int32_t)difference - 65536L;
	}
	return difference;
}

static void ShowSpeed(uint8_t row, int32_t delta, uint16_t elapsed, uint32_t countsPerRev)
{
	int32_t speed = delta * 10000L / elapsed;

	if (countsPerRev > 0U)
	{
		speed = speed * 60L / (int32_t)countsPerRev;
	}
	OLED_ShowSignedNum(row, 3, speed, 7);
}

int main(void)
{
	uint16_t lastTime;
	uint16_t lastA;
	uint16_t lastB;
	uint16_t now;
	uint16_t elapsed;
	uint16_t countA;
	uint16_t countB;
	int32_t deltaA;
	int32_t deltaB;
	int32_t totalA = 0;
	int32_t totalB = 0;

	Motor_Disable();
	OLED_Init();
	Encoder_Init();
	SampleTimer_Init();

	OLED_ShowString(1, 1, "A Total:");
	OLED_ShowString(2, 1, "A:");
	OLED_ShowString(2, 11, A_COUNTS_PER_REV ? "RPM" : "CNT/s");
	OLED_ShowString(3, 1, "B Total:");
	OLED_ShowString(4, 1, "B:");
	OLED_ShowString(4, 11, B_COUNTS_PER_REV ? "RPM" : "CNT/s");

	lastA = TIM_GetCounter(TIM4);
	lastB = TIM_GetCounter(TIM2);
	lastTime = TIM_GetCounter(TIM1);

	while (1)
	{
		now = TIM_GetCounter(TIM1);
		elapsed = (uint16_t)(now - lastTime);
		if (elapsed >= SAMPLE_MS * 10U)
		{
			countA = TIM_GetCounter(TIM4);
			countB = TIM_GetCounter(TIM2);
			deltaA = Encoder_Delta(countA, lastA);
			deltaB = Encoder_Delta(countB, lastB);
			lastA = countA;
			lastB = countB;
			lastTime = now;

			totalA += deltaA;
			totalB += deltaB;
			OLED_ShowSignedNum(1, 9, totalA, 7);
			ShowSpeed(2, deltaA, elapsed, A_COUNTS_PER_REV);
			OLED_ShowSignedNum(3, 9, totalB, 7);
			ShowSpeed(4, deltaB, elapsed, B_COUNTS_PER_REV);
		}
	}
}
